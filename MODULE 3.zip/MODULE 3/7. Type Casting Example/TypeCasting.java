public class TypeCasting{
 public static void main(String[] args) {
    double myDou=45.78;
    int myIntFromDouble=(int)myDou;
    System.out.println("Original double value:"+myDou);
    System.out.println("After casting to int:"+myIntFromDouble);
    int myInt=25;
    double myDoubleFromInt=myInt;
    System.out.println("Original int value:"+myInt);
    System.out.println("After casting to double:"+myDoubleFromInt);
}
}

