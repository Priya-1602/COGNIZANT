public class Operatorprecedence{
  public static void main(String[] args){
    int result1=10+5*2;  
    System.out.println("10+5*2="+result1);
    int result2=(10+5)*2; 
    System.out.println("(10+5)*2="+result2);
    int result3=20/4-2;  
    System.out.println("20/4-2="+result3);
    int result4=10+12/3*2-4;
    System.out.println("10+12/3*2-4="+result4);
    int result5=1+15%4*2;
    System.out.println("10+1%4*2="+result5);
    }
}
