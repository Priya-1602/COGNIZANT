public class SampleClass{
    public void gre(String nam){
    System.out.println("Hello"+nam);
    }
    private void secMethod(){
    System.out.println("This is private");
    }
    public int ad(int x,int y) {
    return x+y;
    }
}

