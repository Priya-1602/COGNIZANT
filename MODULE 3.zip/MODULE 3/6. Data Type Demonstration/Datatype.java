public class Datatype{
  public static void main(String[] args) {
    int int1=100;
    float float1=10.5f;
    double double1=99.99;
    char Char1='A';
    boolean Boolean1=true;
    System.out.println("Integer value: " +int1);
    System.out.println("Float value: " +float1);
    System.out.println("Double value: " +double1);
    System.out.println("Character value: " +Char1);
    System.out.println("Boolean value: " +Boolean1);
    }
}
